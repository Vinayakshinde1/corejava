package com.vinayak.training;

public abstract class Instrument {
	public abstract void play();
}
